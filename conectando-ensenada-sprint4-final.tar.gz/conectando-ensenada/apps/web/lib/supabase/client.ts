import { createBrowserClient } from '@supabase/ssr'
import type { Database } from '@ce/types'

/**
 * Creates a Supabase client for use in Client Components ('use client').
 *
 * Usage:
 *   const supabase = createClient()
 *   const { data } = await supabase.from('profiles').select('*')
 */
export function createClient() {
  return createBrowserClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  )
}
